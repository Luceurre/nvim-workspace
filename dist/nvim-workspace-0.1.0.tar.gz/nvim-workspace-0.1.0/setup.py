# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['nvim_workspace']

package_data = \
{'': ['*']}

install_requires = \
['pynvim>=0.4.3,<0.5.0']

entry_points = \
{'console_scripts': ['nvo = nvim_workspace.nvim_workspace:open']}

setup_kwargs = {
    'name': 'nvim-workspace',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Pierre Glandon',
    'author_email': 'pglandon78@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
