import argparse

parser = argparse.ArgumentParser(description="Open file in a existing Neovim instance.")
parser.add_argument("file")
